#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif
	EXPORT btMinkowskiPenetrationDepthSolver* btMinkowskiPenetrationDepthSolver_new();
#ifdef __cplusplus
}
#endif
