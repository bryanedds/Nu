#include <BulletDynamics/Dynamics/btDynamicsWorld.h>
#include <../BulletFileLoader/btBulletFile.h>
#include <btBulletWorldImporter.h>

#include "btBulletWorldImporter_wrap.h"

#ifndef BULLETC_DISABLE_WORLD_IMPORTERS

btBulletWorldImporter* btBulletWorldImporter_new()
{
	return new btBulletWorldImporter();
}

btBulletWorldImporter* btBulletWorldImporter_new2(btDynamicsWorld* world)
{
	return new btBulletWorldImporter(world);
}

bool btBulletWorldImporter_convertAllObjects(btBulletWorldImporter* obj, bParse_btBulletFile* file)
{
	return obj->convertAllObjects(file);
}

bool btBulletWorldImporter_loadFile(btBulletWorldImporter* obj, const char* fileName)
{
	return obj->loadFile(fileName);
}

bool btBulletWorldImporter_loadFile2(btBulletWorldImporter* obj, const char* fileName,
	const char* preSwapFilenameOut)
{
	return obj->loadFile(fileName, preSwapFilenameOut);
}

bool btBulletWorldImporter_loadFileFromMemory(btBulletWorldImporter* obj, char* memoryBuffer,
	int len)
{
	return obj->loadFileFromMemory(memoryBuffer, len);
}

bool btBulletWorldImporter_loadFileFromMemory2(btBulletWorldImporter* obj, bParse_btBulletFile* file)
{
	return obj->loadFileFromMemory(file);
}

#endif
