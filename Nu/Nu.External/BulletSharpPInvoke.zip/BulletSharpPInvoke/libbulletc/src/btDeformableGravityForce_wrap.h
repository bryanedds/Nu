#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif
	EXPORT btDeformableGravityForce* btDeformableGravityForce_new(const btVector3* gravity);
#ifdef __cplusplus
}
#endif
