#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif
	EXPORT btCollisionDispatcher* btCollisionDispatcherMt_new(btCollisionConfiguration* collisionConfiguration, int grainSize);
#ifdef __cplusplus
}
#endif
