#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif
	EXPORT int btCpuFeatureUtility_getCpuFeatures();
#ifdef __cplusplus
}
#endif
