/*
#include <BulletDynamics/ConstraintSolver/btContactConstraint.h>

#include "btContactConstraint_wrap.h"

btPersistentManifold* btContactConstraint_getContactManifold(btContactConstraint* obj)
{
	return obj->getContactManifold();
}

void btContactConstraint_setContactManifold(btContactConstraint* obj, btPersistentManifold* contactManifold)
{
	obj->setContactManifold(contactManifold);
}
*/
