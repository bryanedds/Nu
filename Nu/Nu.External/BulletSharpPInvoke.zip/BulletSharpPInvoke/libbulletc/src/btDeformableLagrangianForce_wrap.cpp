#include <BulletSoftBody/btDeformableLagrangianForce.h>

#include "btDeformableLagrangianForce_wrap.h"

void btDeformableLagrangianForce_delete(btDeformableLagrangianForce* obj)
{
	delete obj;
}
