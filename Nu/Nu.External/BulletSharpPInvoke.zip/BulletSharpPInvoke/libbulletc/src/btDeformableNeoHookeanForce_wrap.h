#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif
	EXPORT btDeformableNeoHookeanForce* btDeformableNeoHookeanForce_new(btScalar mu, btScalar lambda, btScalar damping);
#ifdef __cplusplus
}
#endif
