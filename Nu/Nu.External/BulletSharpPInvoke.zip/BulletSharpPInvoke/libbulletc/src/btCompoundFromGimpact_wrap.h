#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif
	EXPORT btCompoundShape* btCompoundFromGImpact_btCreateCompoundFromGimpactShape(const btGImpactMeshShape* gimpactMesh, btScalar depth);
#ifdef __cplusplus
}
#endif
