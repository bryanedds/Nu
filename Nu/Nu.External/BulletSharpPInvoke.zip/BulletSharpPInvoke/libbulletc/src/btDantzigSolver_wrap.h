#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif
	EXPORT btDantzigSolver* btDantzigSolver_new();
#ifdef __cplusplus
}
#endif
