#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif
	EXPORT void btDeformableLagrangianForce_delete(btDeformableLagrangianForce* obj);
#ifdef __cplusplus
}
#endif
