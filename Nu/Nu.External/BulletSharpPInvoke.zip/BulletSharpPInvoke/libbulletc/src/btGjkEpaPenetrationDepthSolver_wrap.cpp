#include <BulletCollision/NarrowPhaseCollision/btGjkEpaPenetrationDepthSolver.h>

#include "btGjkEpaPenetrationDepthSolver_wrap.h"

btGjkEpaPenetrationDepthSolver* btGjkEpaPenetrationDepthSolver_new()
{
	return new btGjkEpaPenetrationDepthSolver();
}
