#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif
	EXPORT btGjkEpaPenetrationDepthSolver* btGjkEpaPenetrationDepthSolver_new();
#ifdef __cplusplus
}
#endif
