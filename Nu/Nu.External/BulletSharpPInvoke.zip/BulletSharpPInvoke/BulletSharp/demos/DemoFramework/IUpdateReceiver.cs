﻿namespace DemoFramework
{
    public interface IUpdateReceiver
    {
        void Update(Demo demo);
    }
}
