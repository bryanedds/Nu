namespace BulletSharp
{
	public abstract class ActivatingCollisionAlgorithm : CollisionAlgorithm
	{
		protected internal ActivatingCollisionAlgorithm()
		{
		}
	}
}
