
# OpenVX

In this directory you should place a directory structure for loading proper OpenVX implementation:
- Release\x64\OpenVX.dll
- Release\x86\OpenVX.dll
- Debug\x64\OpenVX.dll
- Debug\x86\OpenVX.dll

## Windows implementations

- AMDOVX: https://github.com/GPUOpen-ProfessionalCompute-Libraries/amdovx-core