#!/bin/bash

dotnet build -c Release SDL2-CS.Core.csproj
