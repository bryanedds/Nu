The generator system algebra we threw together so far -

```
type Distance = single

type Scale = Vector3

type ReproductionRate = int

type DispersalType =
    | DispersalPlane of Box2
    | DispersalBox of Box3
    | DispersalSphere of Sphere

type 'a Dispersal = (Scale * Range) -> (Distance * Range) -> DispersalType -> 'a list

type 'a Generation = (ReproductionRate * Range) -> (Scale * Range) -> (Distance * Range) -> DispersalType -> 'a list -> 'a list

type BlendMap = Vector2 -> single

type 'a AbstractGeneration =
    | SequenceGeneration of 'a Generation list
    | ParallelGeneration of 'a Generation list

type 'a Generator =
    { Dispersals : 'a Dispersal list
      Generations : 'a AbstractGeneration }

type OrientedBillboardElement =
    { Position : Vector3
      Rotation : Quaternion
      Scale : Vector3
      Image : Image AssetTag }

type StaticModelElement =
    { Position : Vector3
      Rotation : Quaternion
      Scale : Vector3
      StaticModel : StaticModel AssetTag }

type OrientedBillboardGenerator =
    OrientedBillboardElement Generator

type StaticModelGenerator =
    StaticModelElement Generator

type FoliageGenerator =
    | OrientedBillboardGenerator of OrientedBillboardGenerator
    | StaticModelGenerator of StaticModelGenerator

type RenderDetail =
    { DetailGenerator : DetailGenerator }
```