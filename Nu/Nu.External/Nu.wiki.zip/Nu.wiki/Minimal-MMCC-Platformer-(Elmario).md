Now let’s look at a more sophisticated MMCC example patterned after the other popular canonical Elm example, Elmario (see the full code here - [https://github.com/bryanedds/Nu/blob/master/Projects/Elmario/Elmario.fs](https://github.com/bryanedds/Nu/blob/master/Projects/Elmario/Elmario.fs)) 

The code here is a bit more involved. It demonstrates how Nu’s uses its scalable built-in physics engine by applying forces rather than using ad-hoc physics computations. Because force application is effectful, we use the Command part of MMCC to drive the physics portion of the program.

```F#
namespace Elmario
open Prime
open Nu
open Nu.Declarative

// this module provides global handles to the game's key simulants.
// having a Simulants module for your game is optional, but can be nice to avoid duplicating string literals across
// the code base.
[<RequireQualifiedAccess>]
module Simulants =

    let Screen = Nu.Screen "Screen"
    let Group = Screen / "Group"
    let Elmario = Group / "Elmario"

// this is our Elm-style command type
type Command =
    | Update
    | Jump
    | Nop
    interface Nu.Command

// this is our Elm-style game dispatcher
type ElmarioDispatcher () =
    inherit GameDispatcher<unit, Message, Command> (())

    // here we define the game's properties and event handling
    override this.Initialize (_, _) =
        [Game.UpdateEvent => Update
         Game.KeyboardKeyDownEvent =|> fun evt ->
             if evt.Data.KeyboardKey = KeyboardKey.Up && not evt.Data.Repeated
             then Jump
             else Nop]

    // here we handle the Elm-style commands
    override this.Command (_, command, _, world) =
        match command with
        | Update ->
            let physicsId = Simulants.Elmario.GetPhysicsId world
            if World.isKeyboardKeyDown KeyboardKey.Left world then
                let world =
                    if World.isBodyOnGround physicsId world
                    then World.applyBodyForce (v3 -2500.0f 0.0f 0.0f) physicsId world
                    else World.applyBodyForce (v3 -750.0f 0.0f 0.0f) physicsId world
                just world
            elif World.isKeyboardKeyDown KeyboardKey.Right world then
                let world =
                    if World.isBodyOnGround physicsId world
                    then World.applyBodyForce (v3 2500.0f 0.0f 0.0f) physicsId world
                    else World.applyBodyForce (v3 750.0f 0.0f 0.0f) physicsId world
                just world
            else just world
        | Jump ->
            let physicsId = Simulants.Elmario.GetPhysicsId world
            if World.getAdvancing world && World.isBodyOnGround physicsId world then
                let world = World.playSound Constants.Audio.SoundVolumeDefault (asset "Gameplay" "Jump") world
                let world = World.applyBodyForce (v3 0.0f 140000.0f 0.0f) physicsId world
                just world
            else just world
        | Nop -> just world

    // here we describe the content of the game including elmario, the ground he walks on, and a rock.
    override this.Content (_, _) =
        [Content.screen Simulants.Screen.Name Vanilla []
            [Content.group Simulants.Group.Name []
                [Content.sideViewCharacter Simulants.Elmario.Name
                    [Entity.Position == v3 0.0f 54.0f 0.0f
                     Entity.Size == v3 108.0f 108.0f 0.0f]
                 Content.block2d "Ground"
                    [Entity.Position == v3 0.0f -224.0f 0.0f
                     Entity.Size == v3 768.0f 64.0f 0.0f
                     Entity.StaticImage == asset "Gameplay" "TreeTop"]
                 Content.block2d "Rock"
                    [Entity.Position == v3 352.0f -160.0f 0.0f
                     Entity.Size == v3 64.0f 64.0f 0.0f
                     Entity.StaticImage == asset "Gameplay" "Rock"]]]]
```

First we see something new - an explicit simulant reference for our main entity, Elmario -

```F#
// this module provides global handles to the game's key simulants.
// having a Simulants module for your game is optional, but can be nice to avoid duplicating string literals across
// the code base.
[<RequireQualifiedAccess>]
module Simulants =

    let Screen = Nu.Screen "Screen"
    let Group = Screen / "Group"
    let Elmario = Group / "Elmario"
```

This simply allows us to refer to our simulants from multiple places in the code without duplicating their address names.

Also new here is the use of our game physics system. Because the physics here update the engine state (yet still in a purely functional manner), Elm-style commands are used rather than messages.

```F#
// this is our Elm-style command type
type Command =
    | Update
    | Jump
    | Nop
    inherit Nu.Command
```

Here we have three commands, one to update the character for left and right movement, one to make him jump, and `Nop`, which is a command that doesn’t do any operations but does allow us to make bindings that may or may not result in a command (as we’ll see below).

```F#
// this is our Elm-style game dispatcher
type ElmarioDispatcher () =
    inherit GameDispatcher<unit, Message, Command> (())
```

Since we don’t need a model this time, we simply pass unit for the first type parameter. And since we’re using just commands (no messages this time), we pass the empty Message type for the second type parameter and `Command `for the third type parameter.

Next up, we will use Nu's ability to define properties explicitly instead of from simulant property lists -

```F#
    // here we define the game's properties and event handling
    override this.Initialize (_, _) =
        [Game.UpdateEvent => Update
         Game.KeyboardKeyDownEvent =|> fun evt ->
             if evt.Data.KeyboardKey = KeyboardKey.Up && not evt.Data.Repeated
             then Jump
             else Nop]
```

Let's break each part down -

```F#
        [Game.UpdateEvent => Update
```

The first initializer creates an `Update` command every frame (when the Game simulant itself is updated).

```F#
         Game.KeyboardKeyDownEvent =|> fun evt ->
             if evt.Data.KeyboardKey = KeyboardKey.Up && not evt.Data.Repeated
             then Jump
             else Nop
```

The second initializer creates either a `Jump` or `Nop` command depending on the state of the keyboard keys as described by its lambda expression.

Let's take an overview of the `this.Command` function that handles these commands (with some code snipped for brevity) -

```F#
// here we handle the Elm-style commands
override this.Command (_, command, _, world) =
    match command with
    | Update -> // snipped here...
    | Jump -> // snipped here...
    | Nop -> just world
```

`Command`s are different from `Message`s in Nu. While `Message`s can transform the simulant's `Model` value, the Command can transform the `World` itself (or just have an IO effect like loading from or writing to disk). Thus, a `Command` can effectively 'side-effect' the world whereas `Message` cannot.

Anyways, let's look in detail at the `Update` case -

```F#
    | Update ->
        let physicsId = Simulants.Elmario.GetPhysicsId world
        if World.isKeyboardKeyDown KeyboardKey.Left world then
            let world =
                if World.isBodyOnGround physicsId world
                then World.applyBodyForce (v3 -2500.0f 0.0f 0.0f) physicsId world
                else World.applyBodyForce (v3 -750.0f 0.0f 0.0f) physicsId world
            just world
        elif World.isKeyboardKeyDown KeyboardKey.Right world then
            let world =
                if World.isBodyOnGround physicsId world
                then World.applyBodyForce (v3 2500.0f 0.0f 0.0f) physicsId world
                else World.applyBodyForce (v3 750.0f 0.0f 0.0f) physicsId world
            just world
        else just world
```

All this code does is look at the state of the keyboard and determine whether or not to apply a linear force to the physics body correlated with the entity from which the `PhysicsId` is found, as well as how much force depending on whether the physics body is on the ground or in the air. It is necessary to put this type of code inside of `Command` because the application of physical force is a 'side-effect' on the World.

Additionally, note that when dealing with physics-driven entities, we usually prefer to move them by applying forces rather than setting their position directly.

```F#
        | Jump ->
            let physicsId = Simulants.Elmario.GetPhysicsId world
            if World.getAdvancing world && World.getBodyGrounded physicsId world then
                let world = World.playSound Constants.Audio.SoundVolumeDefault (asset "Gameplay" "Jump") world
                let world = World.applyBodyForce (v3 0.0f 140000.0f 0.0f) physicsId world
                just world
            else just world
```

Jumping is done similarly, but we also tell the engine to play a jump sound when the entity performs his acrobatic feat. However, since we don't want the sound effect to play when the game is paused in the editor, we check if the World is advancing before doing so. Additionally, we also check if the body of Elmario is grounded so that he can't just jump while in the air.

Having already studied the code for previous example, Nelmish, the rest of the code for Elmario should be self-explanatory.

### Zooming Out

So that wraps up the introductory explanations, but let’s zoom out to add some interesting conceptual detail. In Nu, unlike Elm, this approach is fractal. Each simulant, be it a `Game`, a `Screen`, a `Group`, or an `Entity`, is its own self-contained Elm-style, MMCC program. In this way, Nu is perhaps more sophisticated than Elm — it’s more like a hierarchy of dynamically-configured Elm programs where each program can be individually loaded by as needed, and interactively constructed by external programs such as Gaia (Nu's the real-time game editor). This gives Nu its additional level of pluggability and dynamism that is required for game development.

As you can see, Nu's MMCC API is a declarative way to build games. However, the API's declarative nature might raise questions about performance. Fortunately, Nu's MMCC implementation is so fast that it really should handle about anything you throw at it. Even bullets in a bullet hell shooter should be workable within the declarative MMCC API. So whatever you write in Nu should be with the MMCC API by default. The exceptions really only includes things that require scalability levels sufficient to require implementing in some sort of data-oriented fashion, such as in Nu's ECS (yes, we have one!) This is great because you get simplicity-by-default while being able to opt-in to additional scalability where you need it. And that’s what functional programming is all about!

Using Nu's MMCC API is a great way to build games. By leveraging this powerful architecture, we turn game development from a spaghetti nightmare into a task that is fun again!