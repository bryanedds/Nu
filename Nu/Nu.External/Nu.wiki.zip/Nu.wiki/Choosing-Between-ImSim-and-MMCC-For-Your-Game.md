The first significant development decision you'll probably make with Nu is whether to create an ImSim project or an MMCC project. Which project you should use can sometimes be unclear. Our guidance is as such -

# When To Consider MMCC

If you're building a turn-based game like -

1) a puzzle game (like Tetris, Puyo Puyo, or Panel de Pon)
2) a turn-based JRPG or SRPG (like Dragon Quest, Chrono Trigger, Fire Emblem, or Final Fantasy Tactics)
3) a strategy game or creation simulator (like Civilization or Sim City)

...then consider using the `MMCC` architecture for your game. 

MMCC stands for "Model-Message-Command-Content" and it is inspired by the popular MVU model of the Elm architecture. 

MMCC will give you unparalleled precision and expressiveness in building these sorts of games. 
You can learn more about MMCC [here](https://github.com/bryanedds/Nu/wiki/Model-View-Update-for-Games-via-MMCC).

# When To Consider ImSim

For all other types of games (or when the choice appears ambiguous), consider using `ImSim Game`. ImSim has the most flexible semantics that will work well with any type of game. You can learn more about ImSim [here](https://github.com/bryanedds/Nu/wiki/Immediate-Mode-for-Games-via-ImSim).

ImSim works directly with `Simulants`, which can be one of these following in Nu:
- Game (the top-level world container)
- Screen (only one screen can be active at any time; switching between screens can cue screen transitions)
- Group (used to load Entities together, and for incremental loading of the world)
- Entity (the individual objects in the world)

### Forward compatible

Technically, you can make any type of game with either approach, but some types of games will better utilize the affordances of one approach over the other. Also, it may simply come down to personal preference. If you're an extremely systematic coder and hold precision and program reasoning in the highest regard, you might prefer MMCC in more cases. 

If you're an extremely pragmatic coder and just want to sling code as fast as possible or simply experiment, you might prefer ImSim.

And finally, if you regret your choice later in the project, the two APIs are designed to make porting to one another extremely straightforward. So don't fret too much before landing on one. Again, if you can't choose, just go with ImSim.

# In Summary

Ultimately, choosing between ImSim and MMCC is a choice between development trade-offs. With ImSim, you trade away some semantic instantaneity for lexical immediateness. With MMCC, you trade away some lexical immediateness for semantic instantaneity. 

The best approach depends on your game's essential structure. Whereas ImSim is a little more 'sloppy' (doing more things in bigger functions with more temporal coupling), MMCC is a little more 'hoppy' (doing fewer things in a lot more functions with less temporal coupling). However, both approaches are significantly more rigorous than approaches offered by any other practical game engine.