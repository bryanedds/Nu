These are pages that don't have a branch link in the main wiki page -

[People Whose Work Most Influenced Nu Game Engine](https://github.com/bryanedds/Nu/wiki/People-Whose-Work-Most-Influenced-Nu-Game-Engine)

[Miscellanea](https://github.com/bryanedds/Nu/wiki/Miscellanea)