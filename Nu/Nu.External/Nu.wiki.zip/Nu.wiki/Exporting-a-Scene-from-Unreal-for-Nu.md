Follow this video, albeit with one exception: choose to export as .gltf so that all the textures get exported (unlike with FBX, which just results in only the mesh being exported.

https://www.youtube.com/watch?v=D2KWFnhqyjs

Here are the export settings I'm currently using -

![image](https://github.com/user-attachments/assets/b2120783-76e7-4bbd-9fbc-fb8980c49b9a)

Of course, there's still more work to do with the output, such as swapping the color channels like so -

```
R <- G
G <- B
B <- R
```

...renaming files as appropriate, and setting alpha values of non-albedo PNG files to 255 and saving as TGA or TIF format since PNG is by default reserved for 2D images.