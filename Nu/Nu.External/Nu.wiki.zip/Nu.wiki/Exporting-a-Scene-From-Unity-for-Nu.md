Unity has a means of exporting scenes (or portions of scenes) as .FBX files that Nu can import. Here's the method for exporting them:

1. Have Unity's `FBX Exporter` package [installed](https://github.com/Unity-Technologies/com.unity.formats.fbx/blob/d710ef456658271221e51a5bd2cd81aee28687bb/com.unity.formats.fbx/Documentation~/index.md).
2. Be in a PBR Unity Project.
3. Put all desired objects in empty root game object.
4. Export said root game object, unchecking `Export Unrendered` -
![image](https://github.com/bryanedds/Nu/assets/1625560/27faa9a9-ab74-4270-8c80-bb89e6ce10e5)
5. Delete all .fbx files except the one you exported.
6. Copy over relevant Unity asset folder hierarchy to Nu Assets/{PackageName} folder.
7. Create a `StaticModelHierarchyDispatcher` entity (or `RigidModelHierarchyDispatcher` if you want physics responses) and set the `StaticModel` property to the FBX asset.

If done properly, you'll end up with something like this -

![image](https://github.com/bryanedds/Nu/assets/1625560/5805442d-9ce8-417d-9098-0854ab25f353)

Unfortunately, not everything will come in to Nu exactly as exported, particularly certain light and light probe properties, but this is a rough way to get scenes created in Unity into Nu.