### The Metadata Module

Unlike most everything thing else in Nu, metadata is not accessed via the World API. Instead, it is accessed via the `Metadata` module, like so -

```F#
        override this.GetQuickSize (entity, world) =
            match Metadata.tryGetTextureSizeF (entity.GetBorderImage world) with
            | Some size -> size.V3
            | None -> Constants.Engine.EntitySize2dDefault
```

_QuickSize behavior is often defined in terms of a particular entity's asset's texture size._

For convenience and because it's effectively a static resource, metadata is globally available from the `Metadata` module.

When a Nu game is started (when the World value is initially constructed), all the metadata for the game's assets is synchronously loaded. This includes information like texture sizes, tile map metadata, model vertices, and any other information needed to drive gameplay, physics, or simulation-side presentation logic. Because metadata loading needs to be as fast as possible (since all metadata is loaded at start-up), information not needed like actual texture color data is not loaded.

The following is a user-relevant snapshot of the current `Metadata` API -

```F#
    /// Try to get the metadata of the given asset.
    let tryGetMetadata (assetTag : obj AssetTag) = ...

    /// Try to get the texture metadata of the given asset.
    let tryGetTextureSize (assetTag : Image AssetTag) = ...

    /// Forcibly get the texture size metadata of the given asset (throwing on failure).
    let getTextureSize assetTag = ...

    /// Try to get the texture size metadata of the given asset.
    let tryGetTextureSizeF assetTag = ...

    /// Forcibly get the texture size metadata of the given asset (throwing on failure).
    let getTextureSizeF assetTag = ...

    /// Try to get the tile map metadata of the given asset.
    let tryGetTileMapMetadata (assetTag : TileMap AssetTag) = ...

    /// Forcibly get the tile map metadata of the given asset (throwing on failure).
    let getTileMapMetadata assetTag = ...

    /// Try to get the static model metadata of the given asset.
    let tryGetStaticModelMetadata (assetTag : StaticModel AssetTag) = ...

    /// Forcibly get the static model metadata of the given asset (throwing on failure).
    let getStaticModelMetadata assetTag = ...

    /// Get a copy of the metadata packages.
    let getMetadataPackages () = ...

    /// Attempt to get a copy of a metadata package with the given package name.
    let tryGetMetadataPackage packageName = ...

    /// Get a map of all metadata's discovered assets.
    let getDiscoveredAssets metadata = ...
```

Though metadata is effectively a static resource, metadata can be reloaded via a call to the `Metadata.regenerateMetadata` function, which is done whenever the user manually reloads assets in Nu's editor, Gaia.