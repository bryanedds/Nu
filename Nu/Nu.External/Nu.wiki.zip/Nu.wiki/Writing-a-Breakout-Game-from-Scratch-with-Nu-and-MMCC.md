In this video, we write a Breakout clone from scratch using Nu and MMCC -

Breakout MMCC Development Demo (English) - https://vimeo.com/1050551344

And here's the same video, but in Japanese -

Breakout MMCC Development Demo (Japanese) - https://youtu.be/CV3gBXYTw4w