Nu exposes a very simple audio API via the `World` module -

```F#
        /// Get the currently playing song, if any.
        static member getCurrentSongOpt world = ...
            
        /// Get the currently playing song's position or 0.0.
        static member getCurrentSongPosition world = ...

        /// Get the master volume.
        static member getMasterAudioVolume world = ...

        /// Get the master sound volume.
        static member getMasterSoundVolume world = ...

        /// Get the master song volume.
        static member getMasterSongVolume world = ...

        /// Set the master volume.
        static member setMasterAudioVolume volume world = ...

        /// Set the master sound volume.
        static member setMasterSoundVolume volume world = ...

        /// Set the master song volume.
        static member setMasterSongVolume volume world = ...

        /// Send a message to the audio system to play a song.
        static member playSong fadeInTime fadeOutTime startTime volume song world = ...

        /// Send a message to the audio system to play a sound.
        static member playSound volume sound world = ...

        /// Send a message to the audio system to fade out any current song.
        static member fadeOutSong fadeOutTime world = ...

        /// Send a message to the audio system to stop a song.
        static member stopSong world = ...
```

Since these functions are all side-effecting on the world, you will typically call them from your dispatcher's `Command` override.

However, you don't have to call the song playing functions manually if each screen has its own associated song (here, Assets.Gameplay.DeadBlazeSong) like BlazeVector does -

```F#
        override this.Content (_, _) =
            [...
             Content.screen<GameplayDispatcher> Simulants.Gameplay.Name (Dissolve (Constants.Dissolve.Default, Some Assets.Gameplay.DeadBlazeSong)) [] []
             ...]
```

The `Content.screen` function allows you to associate a particular song asset with the given screen such that it plays when that screen becomes actively, managing cross-fading and cross-screen song persistence for you.

When you wish to control the music on a particular screen yourself, you can simply pass `None`, then in a command hooked to the screen's `Screen.IncomingStartEvent` event, call `World.playSong` yourself.

Additionally, you can control the master volume via Nu's editor, Gaia, via the Audio Player tab like so -

![image](https://github.com/bryanedds/Nu/assets/1625560/60b03a26-237e-44c0-8539-9ced91eb573b)

Note that song volume is set to 0.0f in Gaia at start-up (to save developer sanity over a long project), so if you expect to hear your game's music in the editor but are not, check there first.