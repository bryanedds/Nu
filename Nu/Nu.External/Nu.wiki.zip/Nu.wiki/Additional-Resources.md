### Vsynchronicity Blog

Bryan's blog about Nu Game Engine and adjacent topics -

[vsynchronicity.com](https://vsynchronicity.wordpress.com/)

### Key Resources on Optimizing Rendering with Nvidia Nsight -

In order of recommending viewing -

https://gdcvault.com/browse/gdc-19/play/1026202

https://developer.nvidia.com/blog/the-peak-performance-analysis-method-for-optimizing-any-gpu-workload/

https://developer.nvidia.com/blog/optimizing-vk-vkr-and-dx12-dxr-applications-using-nsight-graphics-gpu-trace-advanced-mode-metrics/

### Additional Tools

Recommended 2D tile editor for Nu, Tiled -

https://www.mapeditor.org/

Bulk file rename tool, Power Rename -

https://learn.microsoft.com/en-us/windows/powertoys/powerrename

Bulk image file conversion program, Light Image Resizer -

https://www.obviousidea.com/windows-software/light-image-resizer/

Color channel swapping in Paint.NET (place .dll in the Effects folder) -

https://github.com/pfandzelter/ColorExchange/tree/master/build

### Informational Resources

Importing Mixamo character and multiple animations using Blender (ignore part about Mixamo Plugin, which isn't used) -

https://www.youtube.com/watch?v=F25_c-Q0_Qw

A bit of advice when implementing your own newtonian physics -

https://youtu.be/yGhfUcPjXuE?t=770