Similar to Unity's Prefabs - https://docs.unity3d.com/Manual/Prefabs.html - and Godot's Scenes, Nu offers a form of design-time structural entity replication and synchronization. Let's give an example of creating a few block-based entities -

First, we'll create a ground using a Block3dDispatcher with a scale of [10 0.1 10] -

![image](https://github.com/bryanedds/Nu/assets/1625560/c3d97743-0c2b-4eeb-b79f-9e16255fb636)

Now create another Block3dDispatcher (do NOT copy paste yet!), stretch it on the Y and place it on top of the ground for a building-like structure -

![image](https://github.com/bryanedds/Nu/assets/1625560/e2caa42c-dd84-48e0-b3a2-e89f835651f7)

Now, moving the camera up and orienting it downward, use Ctrl+Drag on the building-like entity to create more of them -

![image](https://github.com/bryanedds/Nu/assets/1625560/60f973d8-4c8b-4484-93c7-f85923ca189a)

On the original building (Block3d-0002) in the Entity Hierarchy, you will notice additional UI appearing -

![image](https://github.com/bryanedds/Nu/assets/1625560/0d97d043-2909-4a75-a5b8-a57b2a96a452)

This is the magic of Entity Structure Propagation in Nu. Let's try it out!

With the original building selected, click the AlbedoOpt check box in the Material Properties and then adjust its Red color property to 64 like so -

![image](https://github.com/bryanedds/Nu/assets/1625560/065c6aff-3a8d-4ab5-95aa-e5cd37a99fc6)

Now we will synchronize this entity's changes to the entities that were copied from it by clicking the `Push` button in the Entity Hierarchy next to it -

![image](https://github.com/bryanedds/Nu/assets/1625560/ff41a362-b5a9-48a7-988e-b679243b5d2c)

Notice how copied from entity's colors are synchronized! This happens because each time you copy and paste an entity, the new entity's PropagationSourceOpt property is set to the address of entity it was copied from -

![image](https://github.com/bryanedds/Nu/assets/1625560/fd0cce89-55e9-43c5-9264-4dc1da4101e3)
(sorry that the `Propaga` property name is cut off...)

If you want to sever this connection, you can click the check box on the PropagationSourceOpt (don't do this yet, tho). Alternatively, you can change that source to any other entity. If you do, the `Push` button will appear on the entity that becomes the source.

Now, let's change the color of a building other than the propagation source -

![image](https://github.com/bryanedds/Nu/assets/1625560/565616fe-a4b2-44ca-9689-042894eac33c)

Next, let's change the color of the _original_ building and then hit its `Push` button -

![image](https://github.com/bryanedds/Nu/assets/1625560/02ef1874-1cf4-4297-bee9-e82d3e09dfb2)

You'll notice that when you Push again, it only affects the color of the entities whose color weren't manually changed by the user. When you change a property of a entity that is a propagation target, that property's value is overridden. So when the same property of the propagation source is changed, it won't propagate when pushed. The non-overridden properties will continue to be propagated tho!

Now let's make some structural changes to the original building by copy dragging on the original building above it -

![image](https://github.com/bryanedds/Nu/assets/1625560/812e7002-b477-4402-9dea-b434e778f470)

Next, click the check box on the PropagationSourceOpt property to unlink it from the entity you just sourced it from -

![image](https://github.com/bryanedds/Nu/assets/1625560/447aa467-0862-47a9-81ab-6517deaa8fdd)
(we don't want this entity to be the target of the original building's propagated changes)

Next, change the scale of the new block and move around where you like it relative to the original building. And then drag the new entity in the Entity Hierarchy on top of the original building entity to make it a child of it like so -

![image](https://github.com/bryanedds/Nu/assets/1625560/cce2e799-bcd3-437e-b0a2-9e874792d755)

Now when we click the `Push` button again, and you'll see that child block be propagated to the other targets -

![image](https://github.com/bryanedds/Nu/assets/1625560/f9d9036a-83cb-4f18-b647-cf77a4141a14)

As you can see, it's not just properties that propagate, but also child entities and their properties. This is why this is called 'structural propagation'.

If you want to save the propagation source entity to a file to use it elsewhere, say in other projects, you can select it and use the Save Entity feature -

![image](https://github.com/bryanedds/Nu/assets/1625560/e96bc1c2-c792-4a49-ab92-627f60e5738c)

Then load it in other projects via the Open Entity feature.

As you can imagine, you can mix and match this feature use across entity hierarchies, recursively building up propagation sources with significant complexity. There are trade-offs to this way of doing structural propagation as opposed to, say, Unity Prefabs. Unlike Unity Prefabs, structure propagation is driven manually by clicking the `Push` button. That is, changing the propagation source will not automatically result in changes to its propagation targets.

While the manual interaction required might be a bit of a downside, if you've used the Prefab workflow in Unity before, you'll see how this system is as expressive yet much easier to use and manage in the common case. Because propagation links are automatically created via the existing copy-paste workflow, there's very little manual intervention required to leverage this system. You don't have to manage a separate asset resource for each propagation source. Additionally, this approach yielded a significantly simpler implementation, running around 300 lines of code or so.

This set of techniques can be a good way to 'block-out' various scenes, adding detail as you go along -
![image](https://github.com/bryanedds/Nu/assets/1625560/6820f46d-178c-4069-9058-dfc58881897e)

Because structural propagation works recursively, you can reparent the buildings under the ground block, then duplicate the block like so -

![image](https://github.com/bryanedds/Nu/assets/1625560/ba4456e8-eeb2-4bf5-8e02-329468d2b723)

And if you change a building in the original area, you can click `Push` on the ground block to propagate those changes like so -

![image](https://github.com/bryanedds/Nu/assets/1625560/a1da3eff-765f-41e0-b231-2550e0e7e595)