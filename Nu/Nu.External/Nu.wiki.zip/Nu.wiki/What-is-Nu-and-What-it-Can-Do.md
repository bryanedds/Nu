### A Mature, Functional, 2D and 3D Game Engine written in F#

Let me expand on each of those terms –

`Mature`

Nu is mature and exposes multiple levels of programmability depending on your performance needs. At the high level, there’s the MVU-like MMCC programming API. At the low level, there’s an algebraic Entity-Component-System API called `Ecs`. By default you’ll be using the declarative MMCC API, but you can drop down to the ECS if you need to scale to many tens of thousands of active on-screen entities.

There is a 2D tile map system that utilizes `Tiled#`, 2D physics via `Aether Physics`, and 3D physics via `Bullet` (and `BulletSharpPInvoke`). Both 2D and Physically-Based 3D rendering are done with cross-platform `OpenGL 4.1`. Audio and other IO systems are handled in a cross-platform way with `SDL2` / `SDL2#`. There is also an asset management system via `AssetGraph` to make sure your game can run on memory-constrained devices such as mobile. There is a declarative special effects system called, appropriately enough, `EffectSystem`, as well as an efficient `ParticleSystem`. On top of all that, there is a built-in WYSIWYG editor called Gaia.

`Functional (w/ Imperative Configuration)`

By default in the editor, Nu is configured to run in an immutable mode. In this mode, all of the simulation backing data encapsulated behind the World API is implemented with functional data structures that can be snapshotted and restored. This snapshotting is how Nu's editor, Gaia, implements its Undo and Redo operations. However, for optimal performance, Nu is configured to use mutating data structures under the hood instead when outside of the editor. Nu can be configured to run either way in both contexts, however.

`2D and 3D Game Engine`

Nu is not a code library. It is a game software framework. Thus, it sets up a specific way of approaching and thinking about the design of 2D and 3D games. Nu is intended to be a broadly generic toolkit for 2D and 3D game development. This is why Nu is made available via an engine source forking model rather than as a black-box nuget library.

`F#`

We know what F# is, so why use it? First, because of its cross-platform nature. Nu runs on .NET Core as well as on Mono for portability to Linux and other platforms. But more on why F#. F# is probably the best mainstream language available for writing a cross-platform functional game engine. Unlike Clojure, F#’s static type system makes the code easier to reason about and potentially more efficient. Unlike Scala, F# offers a simple and easy-to-use semantic model. Unlike Haskell, you get an intuitive and a well-tooled debugging experience, with no need babysit effects / monads / etc. Unlike JVM languages generally, F# allows us to code and debug with Visual Studio. Finally, I speculate that game developers have more familiarity with the .NET ecosystem than the JVM, so that leverage is at hand.

### Model-View-Update via `MMCC`

I have said many times that Model-View-Update (or `MVU`) is the 'killer app' of functional programming. Until MVU came along, most arguments about the benefits of functional programming resided primarily in the space of the theoretical. But when Elm introduced the world to MVU with it's incredibly clean authoring form factor, the space of discussion changed forever.

With Nu's generalization of `MVU` via `MMCC` (Model-Message-Command-Content), it is the first and still only practical game engine positioned to bring the killer benefits of this incredible declarative development form factor to game developers.