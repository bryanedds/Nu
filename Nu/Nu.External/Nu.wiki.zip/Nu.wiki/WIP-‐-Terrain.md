Terrain is currently in-design. These are developer design artifacts for now.

```F#
type Endianness =
    | LittleEndian
    | BigEndian

type RawFormat =
    | RawUInt8
    | RawUInt16 of Endianness
    | RawUInt32 of Endianness
    | RawSingle of Endianness

type RawHeightMap =
    { Resolution : Vector2i
      RawFormat : RawFormat
      RawAsset : Raw AssetTag }

type HeightMap =
    | RawHeightMap of RawHeightMap
    | ImageHeightMap of Image AssetTag // only supports 8-bit depth on R channel

// NOTE: doesn't use metalness for now in order to increase number of total materials per terrain.
type TerrainLayer =
    { AlbedoImage : Image AssetTag
      RoughnessImage : Image AssetTag
      AmbientOcclusionImage : Image AssetTag
      NormalImage : Image AssetTag
      // TODO: figure out the precise relationship between layer scale and tile size
      // TODO: figure out if 'Scale' is the right nomenclature or if it should be 'Repeat' or 'Tile' or something else.
      LayerScale : Vector2 }

type SplatMap =
    | RgbaMap of Image AssetTag
    | RedsMap of Image AssetTag array

type FlatMaterial =
    { AlbedoImage : Image AssetTag
      RoughnessImage : Image AssetTag
      AmbientOcclusionImage : Image AssetTag
      NormalImage : Image AssetTag }

type SplatMaterial =
    { AlbedoImage : Image Asset
      TerrainLayers : TerrainLayer array
      SplatMap : SplatMap }

type TerrainMaterial =
    | FlatMaterial of FlatMaterial
    | SplatMaterial of SplatMaterial

// NOTE: we're not supporting auto-normalization, so no need to represent normalized min and max heights.
type TerrainDescriptor =
    { Bounds : Box3
      Segments : Vector2i
      HeightMap : HeightMap
      Material : TerrainMaterial }
```

WIP branch is here -

https://github.com/bryanedds/Nu/compare/terrain?expand=1