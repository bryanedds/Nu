When exporting a static FBX model from Blender for use in Nu, use these export settings -

![image](https://github.com/user-attachments/assets/711b7ab2-37fc-4da7-89a8-dcea4227111f)

When exporting an animated FBX model from Blender for use in Nu, use these export settings -

![image](https://github.com/user-attachments/assets/9ee376fa-21e2-4467-a691-5ed613130f74)