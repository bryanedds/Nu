TODO - currently we've not yet made material for this, but you can check out our equivalent MMCC material - 

[Writing a Breakout Game from Scratch with Nu and MMCC](https://github.com/bryanedds/Nu/wiki/Writing-a-Breakout-Game-from-Scratch-with-Nu-and-MMCC)