### Exporting static FBX models

Set up your exporter like so -

![image](https://github.com/bryanedds/Nu/assets/1625560/ba5dcba2-917c-491e-adba-0f1acbbf76cc)

### Exporting animated FBX models

Set up your exporter like so -

![image](https://github.com/user-attachments/assets/d7e66bfb-c917-461f-9f38-23446e97321b)

Note that setting `Forward` to +Z is needed only if you model your characters facing the camera like Mixamo models have been.