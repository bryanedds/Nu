TODO: basic content.

Nu has two physics engines, AetherPhysics for 2D and Jolt Physics for 3D.

### Fast Imperative Physics Behind a Purely Functional API?

This might seem impossible, but with a technique we developed, it is actually entirely possible to wrap any imperative representation behind a purely functional API so long as it can support certain operations -

TODO: more detail.

### Synchronized or Manual Physics Motion

You can set the `PhysicsMotion` property of a physics-based entity to `ManualMotion` to prevent changes to the entity's transformation properties from being automatically synchronized with the physics backend. However, enabling `ManualMotion` also means that whenever you need to change the physical transformation of such an entity, you must do so via a function call such as `World.setBodyCenter`. Changing an entity's transformation via its transform property will have no effect on its physical representation when in ManualMotion.

TODO: more detail.