We provide an API that is premised on the stack-based identity idiom first seen in ImGui. ImSim is a simplifying declarative API for game development.

Compared to ImGui, the first difference you will see with ImSim is that it works for **all simulant types**, not just gui entities. ImSim is a simulation-wide generalization of the purely user-interface technology that inspired it. In short, ImSim allows you 'immediate mode all the things' rather than just user interfaces like ImGui!

Probably the best way to see how to use the declarative ImSim API is to read the following tutorial page -

[Minimal ImSim Example (Jump Box)](https://github.com/bryanedds/Nu/wiki/Minimal-ImSim-Example-(Jump-Box))