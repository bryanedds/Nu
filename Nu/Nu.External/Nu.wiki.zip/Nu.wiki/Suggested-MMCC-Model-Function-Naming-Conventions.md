When using MMCC, you're probably going to end up with a lot of model functions. Therefore, you're going to need some conventions on how to name them if you want to stay consistent. This is the nomenclature that Nu developers recommendation to users -

* `set_` - transforms a specific portion of the model in a functional way, EG, `setHitPoints`.
* `map_` - like `set_` but a higher order function with a `mapper` parameter, EG, `mapAnimationState`.
* `eval_` - computes output from a model based on some parameters, often w/ in-depth calculations, EG, `evalAttack`.
* `apply_` - takes a set of parameters and a model and produces a transformed model, EG, `applyDamage`.
* `update_` - transforms model through time, EG, `updateAnimation`

Instead of using the `set_` nomenclature, you might use `with_` instead. This probably depends on taste. Some think the use of set_ looks too much like it indicates mutation, while other's feel it's more natural once one gets into a pervasively functional mindset. Whichever you choose, do be consistent for your project.

Beyond this, we strongly suggest using the programming patterns found in the example Nu projects.