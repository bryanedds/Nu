### Overlays

Overlays accomplish two extremely important functions in Nu. First, they reduce the amount of stuff written out to (and consequently read in from) serialization files. Second, they provide the user with a way to abstract over property values that multiple entities hold in common. User-defined overlays, called ‘overlay routes’, are defined in a file that is included with every new Nu game project called Overlayer.nuol. Additionally, for every dispatcher and facet type that the engine is informed of, an overlay route with a matching name is defined with values set to the type’s Properties.

Let’s look at the OmniBlade’s overlay definitions in [Overlayer.nuol](https://github.com/bryanedds/Nu/blob/master/Projects/OmniBlade/Overlayer.nuol) –

```
[[OmniButtonOverlay
  [ButtonOverlay]
  [ButtonDispatcher]
  [[ClickSoundOpt [Some [Gui Affirm]]]
   [DownTextOffset [0 -3]]
   [DownImage [Gui ButtonDown]]
   [Font [Gui Font]]
   [TextColor #FFFFFFFF]
   [TextDisabledColor #C0C0C0C0]
   [UpImage [Gui ButtonUp]]]]
 [OmniTextOverlay
  [TextOverlay]
  [TextDispatcher]
  [[Font [Gui Font]]
   [TextColor #FFFFFFFF]
   [TextDisabledColor #C0C0C0C0]]]
 [OmniToggleButtonOverlay
  [ToggleButtonOverlay]
  [ToggleButtonDispatcher]
  [[Font [Gui Font]]
   [PressedTextOffset [0 -3]]
   [TextColor #FFFFFFFF]
   [TextDisabledColor #C0C0C0C0]
   [ToggledTextOffset [0 -3]]
   [ToggleSoundOpt [Some [Gui Affirm]]]]]
 [OmniRadioButtonOverlay
  [RadioButtonOverlay]
  [RadioButtonDispatcher]
  [[Font [Gui Font]]
   [PressedTextOffset [0 -3]]
   [TextColor #FFFFFFFF]
   [TextDisabledColor #C0C0C0C0]
   [DialedTextOffset [0 -3]]
   [DialSoundOpt [Some [Gui Affirm]]]]]]
```

Obviously enough, the first field, OmniButtonOverlay, is the name of the overlay.

The second field, [ButtonOverlay], is the list of overlays that the overlay will inherit properties from. This list is composed of a single ‘intrinsic’ overlay composed of the default properties of the ButtonDispatcher. It’s called an ‘intrinsic’ overlay because it is automatically created by the engine.

The third field, [ButtonDispatcher], is the list of dispatchers that the overlay will be automatically applied to.
The remaining list is the set of properties that will be overlaid and their overlaid values.

Overlays avoid a ton of duplication while allowing changes to them to automatically propagate to the entities to which they are applied.