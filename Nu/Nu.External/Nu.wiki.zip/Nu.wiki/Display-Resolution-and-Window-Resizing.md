Nu has a concept of `virtual resolution`. Virtual resolution represents the actual 2D coordinates of the display area, which is independent of window size. The resulting display resolution is defined as `DisplayVirtualResolution * DisplayScalar`, which default to `[640 360]` and `2`, respectively. We chose this virtual resolution because it's a fraction of 1080, 1440, and 4k. Other than changing DisplayVirtualResolution, there's currently no way to change the aspect ratio.

Note that the resulting display resolution is also the default window size. When you resize the window in Nu, you're actually just changing the `DisplayScalar`.

You can change `DisplayVirtualResolution` and `DisplayScalar` in App.config like so -

```xml
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <appSettings>
    <add key="DisplayVirtualResolution" value="[320 180]" />
    <add key="DisplayScalar" value="3" />
  </appSettings>
</configuration>
```

Currently, `DisplayScalar` can only be set to an integer value.