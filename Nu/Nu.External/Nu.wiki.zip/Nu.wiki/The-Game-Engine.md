### The World

This is the type that stores all of the program state and functionality, including the simulant state, the event system, the physics engines, the renderers, the audio player, and anything else you can think of. The World value along with its module is your main access point to Nu's complete API. Because Nu exposes a functional API (unless configured otherwise for speed), most operations on a world value produce a new, updated world value. This is what functional programmers often call a 'crank-the-world' style.

### The Simulation Hierarchy

By looking at [the Nelmish](https://github.com/bryanedds/Nu/tree/master/Projects/Nelmish) example, you might be able to make inferences of how Nu simulations are defined and structured. Let’s make sure you have a clear idea.

First and foremost, Nu's simulation engine was designed for games. This may seem an obvious statement, but it has some implications that vary it from other middleware technologies.

Nu comes with a family of simulation types out of the box, allowing you to house the various parts of your game inside of it. Here’s the overall structure of a game simulation as provided by Nu –

`Game` --> `[Screen]` --> `[Group]` --> `[Entity]`

In the above diagram, `X` --> `[Y]` denotes a one-to-many relationship, and `[X]` --> `[Y]` denotes that each X has a one-to-many relationship with Y. So for example, there is only one active Game in existence, but the Game can contain many Screens (such as a title screen and a credits screen), and each Screen may contain multiple Groups (such as a gui group and a scene group), where each Group may contain multiple Entities that have some user-determined relationship to each other (such as all entities that implement the containing screen's gui).

Let’s break down what each of Nu’s of these types represent in detail.

### The Game

The Game is a one-of-a-kind simulant that is used to describe how your game's various screens hook together. In an ImSim context, you set whether the currently defined screen should be selected by passing a boolean to the second argument of the World.beginScreen function like so -

```F#
let results = World.beginScreen<GameplayDispatcher> Simulants.Gameplay.Name (myGame = Gameplay) (Dissolve (Constants.Dissolve.Default, None)) [] world
```

In an MMCC context, by defining the game's DesiredScreen property based on the game's model value, you can direct the engine to transition among its various screens like so -

```F#
        // here we define the game's property values and event handling
        override this.Definitions (model, _) =
            [Game.DesiredScreen :=
                match model with
                | Splash -> Desire Simulants.Splash
                | Title -> Desire Simulants.Title
                | Credits -> Desire Simulants.Credits
                | Gameplay -> Desire Simulants.Gameplay
             ...]
```

### Screens

Screens are precisely what they sound like – a way to implement a single ‘screen’ of interaction in your game. In Nu’s conceptual model, a game is nothing more than a series of interactive screens to be traversed like a graph. The main simulation occurs within a given screen, just like everything else. Familiar uses of 'screens' in games include splash screens, title screens, credits screens, and sim or gameplay screens - the screens where the bulk of gameplay interactions take place.

### Groups

Groups represent collections of entities that are logically related in some way. Like `Scenes` in Unity, you can save individual Groups to .nugroup files and load any number of them at the same time (look under the `Group` menu in Gaia for the `Open Group` and `Save Group` features). In a small game, often there will only be one group per screen. If a game has a large level though, you might create a group for each detailed building or region. Groups are very purpose-agnostic, so you can use groups to organize entities in a bespoke manner, like how Blaze Vector uses one group for each of its randomly composed level segments.

Like layers in a paint program, each group has a Visible property that can be used to hide or show all of its contained entities in the editor. Also, you can only click and drag entities that are in the editor's currently selected group. If you're coming from Unity, the conceptual analog of the Nu Group is the Unity Scene.

IMPORTANT NOTE: one thing that groups are usually **NOT** for is partitioning gui entities inside a single screen. For example, for a given modal dialog, you might think you would want to create a new group to contain only the entities of which that modal dialog is composed. This is usually not the case! Related gui entities are intended to be parented by common parent _entity_ - such as a Panel or Composite - rather than by a group specifically created for them. Please keep this in mind when organizing your simulation!

### Entities (and Facets)

And here we come down to brass tacks. Entities represent individual interactive ‘things’ in your game, such as user-interface buttons, tile maps, and physics boxes. What differentiates a button entity from a box entity, though? Well, each entity picks up its unique attributes from its dispatcher and facets. Let's understand in more detail first what dispatchers are, then facets.

### Dispatchers in Detail

A Dispatcher is a stateless F# class that configures the base properties and behaviors of a simulant. You've already seen an example of a GameDispatcher. Let's look at an EntityDispatcher from the engine code, in particular, the Character2dDispatcher -

```F#
[<AutoOpen>]
module Character2dDispatcherExtensions =
    type Entity with
        member this.GetCharacter2dIdleImage world : Image AssetTag = this.Get (nameof this.Character2dIdleImage) world
        member this.SetCharacter2dIdleImage (value : Image AssetTag) world = this.Set (nameof this.Character2dIdleImage) value world
        member this.Character2dIdleImage = lens (nameof this.Character2dIdleImage) this this.GetCharacter2dIdleImage this.SetCharacter2dIdleImage
        member this.GetCharacter2dJumpImage world : Image AssetTag = this.Get (nameof this.Character2dJumpImage) world
        member this.SetCharacter2dJumpImage (value : Image AssetTag) world = this.Set (nameof this.Character2dJumpImage) value world
        member this.Character2dJumpImage = lens (nameof this.Character2dJumpImage) this this.GetCharacter2dJumpImage this.SetCharacter2dJumpImage
        member this.GetCharacter2dWalkSheet world : Image AssetTag = this.Get (nameof this.Character2dWalkSheet) world
        member this.SetCharacter2dWalkSheet (value : Image AssetTag) world = this.Set (nameof this.Character2dWalkSheet) value world
        member this.Character2dWalkSheet = lens (nameof this.Character2dWalkSheet) this this.GetCharacter2dWalkSheet this.SetCharacter2dWalkSheet
        member this.GetCharacter2dFacingLeft world : bool = this.Get (nameof this.Character2dFacingLeft) world
        member this.SetCharacter2dFacingLeft (value : bool) world = this.Set (nameof this.Character2dFacingLeft) value world
        member this.Character2dFacingLeft = lens (nameof this.Character2dFacingLeft) this this.GetCharacter2dFacingLeft this.SetCharacter2dFacingLeft

/// Gives an entity the base behavior of 2d physics-driven character in a platformer.
type Character2dDispatcher () =
    inherit Entity2dDispatcher (true, false, false)

    static let computeWalkCelInset time delay (celSize : Vector2) (celRun : int) =
        let compressedTime =
            match (time, delay) with
            | (UpdateTime time, UpdateTime delay) -> time / delay
            | (TickTime time, TickTime delay) -> time / delay
            | (_, _) -> failwith "Cannot operate on incompatible GameTime values."
        let frame = compressedTime % int64 celRun
        let i = single (frame % 3L)
        let j = single (frame / 3L)
        let offset = v2 (i * celSize.X) (j * celSize.Y) 
        box2 offset celSize

    static member Facets =
        [typeof<RigidBodyFacet>]

    static member Properties =
        [define Entity.CelSize (v2 28.0f 28.0f)
         define Entity.CelRun 8
         define Entity.AnimationDelay (GameTime.ofSeconds (1.0f / 15.0f))
         define Entity.BodyType Dynamic
         define Entity.AngularFactor v3Zero
         define Entity.SleepingAllowed true
         define Entity.GravityOverride (Some (Constants.Physics.GravityDefault * Constants.Engine.Meter2d * 3.0f))
         define Entity.BodyShape (CapsuleShape { Height = 0.5f; Radius = 0.25f; TransformOpt = None; PropertiesOpt = None })
         define Entity.Character2dIdleImage Assets.Default.Character2dIdle
         define Entity.Character2dJumpImage Assets.Default.Character2dJump
         define Entity.Character2dWalkSheet Assets.Default.Character2dWalk
         define Entity.Character2dFacingLeft false]

    override this.Update (entity, world) =
        if entity.GetEnabled world then
            // we have to use a bit of hackery to remember whether the character is facing left or
            // right when there is no velocity
            let facingLeft = entity.GetCharacter2dFacingLeft world
            let velocity = World.getBodyLinearVelocity (entity.GetBodyId world) world
            if facingLeft && velocity.X > 1.0f then entity.SetCharacter2dFacingLeft false world
            elif not facingLeft && velocity.X < -1.0f then entity.SetCharacter2dFacingLeft true world

    override this.Render (_, entity, world) =
        let bodyId = entity.GetBodyId world
        let facingLeft = entity.GetCharacter2dFacingLeft world
        let velocity = entity.GetLinearVelocity world
        let celSize = entity.GetCelSize world
        let celRun = entity.GetCelRun world
        let animationDelay = entity.GetAnimationDelay world
        let mutable transform = entity.GetTransform world
        let struct (insetOpt, image) =
            if not (World.getBodyGrounded bodyId world) then
                let image = entity.GetCharacter2dJumpImage world
                struct (ValueNone, image)
            elif velocity.X < 5.0f && velocity.X > -5.0f then
                let image = entity.GetCharacter2dIdleImage world
                struct (ValueNone, image)
            else
                let image = entity.GetCharacter2dWalkSheet world
                struct (ValueSome (computeWalkCelInset world.GameTime animationDelay celSize celRun), image)
        World.enqueueLayeredOperation2d
            { Elevation = transform.Elevation
              Horizon = transform.Horizon
              AssetTag = image
              RenderOperation2d =
                RenderSprite
                    { Transform = transform
                      InsetOpt = insetOpt
                      ClipOpt = ValueNone
                      Image = image
                      Color = Color.One
                      Blend = Transparent
                      Emission = Color.Zero
                      Flip = if facingLeft then FlipH else FlipNone }}
            world
```

Unlike the other dispatchers you've seen so far, this dispatcher is NOT ImSim or MMCC-based, but rather a uses the Classic Nu API that existed before the either declarative API was added to the engine. All of Nu's pre-built dispatchers use the Classic Nu API. Classic-style entity dispatchers have a subset of the overridable functions available to their MMCC counterpart, which is as follows -

```F#
    /// The presence override, if any.
    abstract PresenceOverride : Presence voption

    /// Register an entity when adding it to a group.
    abstract Register : entity : Entity * world : World -> unit

    /// Unregister an entity when removing it from a group.
    abstract Unregister : entity : Entity * world : World -> unit

    /// Attempt to ImSim process an entity.
    abstract TryProcess : zeroDelta : bool * entity : Entity * world : World -> unit

    /// Update an entity.
    abstract Update : entity : Entity * world : World -> unit

    /// Render an entity.
    abstract Render : renderPass : RenderPass * entity : Entity * world : World -> unit

    /// Apply physics changes from a physics engine to an entity.
    abstract ApplyPhysics : center : Vector3 * rotation : Quaternion * linearVelocity : Vector3 * angularVelocity : Vector3 * entity : Entity * world : World -> unit

    /// Send a signal to an entity.
    abstract Signal : signalObj : obj * entity : Entity * world : World -> unit

    /// Attempt to get the fallback model value if the dispatcher defines one.
    abstract TryGetFallbackModel<'a> : modelSymbol : Symbol * entity : Entity * world : World -> 'a option

    /// Attempt to synchronize content of an entity.
    abstract TrySynchronize : initializing : bool * entity : Entity * world : World -> unit

    /// Get the default size of an entity.
    abstract GetAttributesInferred : entity : Entity * world : World -> AttributesInferred

    /// Attempt to pick an entity with a ray.
    abstract RayCast : ray : Ray3 * entity : Entity * world : World -> Intersection array

    /// Participate in defining additional editing behavior for an entity via the ImGui API.
    abstract Edit : op : EditOperation * entity : Entity * world : World -> unit

    /// Attempt to truncate an entity model.
    abstract TryTruncateModel<'a> : model : 'a -> 'a option

    /// Attempt to untruncate an entity model.
    abstract TryUntruncateModel<'a> : model : 'a * Entity : Entity * world : World -> 'a option
```

Additionally, there are special static members that you can define to further specify the dispatcher -

```F#
    /// Configure the facets intrinsically used by an entity dispatcher.
    static member Facets : Type list

    /// Configure which properties a dispatcher attaches to a simulant and the default value of each property.
    static member Properties : PropertyDefinition list
```

As seen in the example, you're able to use type extensions to define new property getters, property setters, and property lenses, like the dispatcher does above -

```F#
[<AutoOpen>]
module FpsDispatcherExtensions =
    type Entity with
        member this.GetStartUpdateTime world : int64 = this.Get (nameof this.StartUpdateTime) world
        member this.SetStartUpdateTime (value : int64) world = this.Set (nameof this.StartUpdateTime) value world
        member this.StartUpdateTime = lens (nameof this.StartUpdateTime) this this.GetStartUpdateTime this.SetStartUpdateTime
        member this.GetStartDateTime world : DateTimeOffset = this.Get (nameof this.StartDateTime) world
        member this.SetStartDateTime (value : DateTimeOffset) world = this.Set (nameof this.StartDateTime) value world
        member this.StartDateTime = lens (nameof this.StartDateTime) this this.GetStartDateTime this.SetStartDateTime
```

Nu's definition of a lens is just a value that can get and optionally set the property of a simulant.

User-defined lenses like the above `StartUpdateTime` lens are what allow us to easily write new equalities in MMCC like so -

```F#
    StartUpdateTime := someChangingUpdateTime
```

...or access the property value from an entity handle like so -

```F#
    let oldStartUpdateTime = someEntity.GetStartUpdateTime world
    let world = someEntity.SetStartUpdateTime newStartUpdateTime world
```

Here, we use the new lens and the `define` function to indicate that an entity attaches the StartUpdateTime property with the initial value of `DateTimeOffset.Now` -

```F#
    static member Properties =
        [nonPersistent Entity.StartUpdateTime 0L
         nonPersistent Entity.StartDateTime DateTimeOffset.Now]
```

But there are also alternative ways to attach properties, such as `nonPersistent`, `variable`, and `computed`. A property defined via `nonPersistent` tells the engine to avoid serializing any property with that name. An example from elsewhere in the engine -

```F#
        static member Properties =
            [...
             nonPersistent Entity.TmxMap (TmxMap.makeDefault ())
             ...]
```

A property defined via `variable` is non-persistent and rather than having a pre-defined initial value, has its initial value computed via a callback when the property is attached to a specific entity. An example from the engine -

```F#
        static member Properties =
            [...
             variable Entity.EffectHistory (fun _ -> Deque<Effects.Slice> (inc Constants.Effects.EffectHistoryMaxDefault))
             ...]
```

A property defined via `computed` is non-persistent and also computed via a getter and setter rather than having a value backing store. An example from the engine -

```F#
        static member Properties =
            [...
             computed Entity.BodyId (fun (entity : Entity) _ -> { BodySource = entity; BodyIndex = 0 }) None
             ...]
```

You can find many examples of pre-defined entity dispatchers in [WorldDispatchers.fs](https://github.com/bryanedds/Nu/blob/master/Nu/Nu/World/WorldDispatchers.fs).

### Facets in Detail

So what are facets? Well, as facet is very similar to a dispatcher, but instead of statically defining a base set of properties and behaviors for an entity, it dynamically augments an existing entity with additional properties and behaviors. These play a similar role as MonoBehaviors in Unity; they are added - sometimes at runtime - to an entity in order to give additional capabilities to an entity. However, unlike MonoBehaviors, only one instance of each type of facet can be added to a given entity at a time. You can't add multiple StaticSpriteFacets to a single entity, for example. However, because facets attach properties to an entity the same way a dispatcher does, you can simply and directly access facet-attaached properties using the normal property access API like so -

```F#
    someEntity.GetStaticSpriteImage world
```

...rather than having to inefficiently look-up the MonoBehavior component (or binding the mutable component reference in the editor to another MonoBehavior's field...) and then calling one of its getters. Dynamically attached properties in Nu have a constant-time look-up, so they're efficient to use in a convenient manner. In that way, they're a little more like using mixins or non-diamond multiple-inheritance.

To make things more concrete, let's look at a simple facet from the engine, the StaticSpriteFacet -

```F#
[<AutoOpen>]
module StaticSpriteFacetExtensions =
    type Entity with
        member this.GetInsetOpt world : Box2 option = this.Get (nameof this.InsetOpt) world
        member this.SetInsetOpt (value : Box2 option) world = this.Set (nameof this.InsetOpt) value world
        member this.InsetOpt = lens (nameof this.InsetOpt) this this.GetInsetOpt this.SetInsetOpt
        member this.GetStaticImage world : Image AssetTag = this.Get (nameof this.StaticImage) world
        member this.SetStaticImage (value : Image AssetTag) world = this.Set (nameof this.StaticImage) value world
        member this.StaticImage = lens (nameof this.StaticImage) this this.GetStaticImage this.SetStaticImage
        member this.GetColor world : Color = this.Get (nameof this.Color) world
        member this.SetColor (value : Color) world = this.Set (nameof this.Color) value world
        member this.Color = lens (nameof this.Color) this this.GetColor this.SetColor
        member this.GetBlend world : Blend = this.Get (nameof this.Blend) world
        member this.SetBlend (value : Blend) world = this.Set (nameof this.Blend) value world
        member this.Blend = lens (nameof this.Blend) this this.GetBlend this.SetBlend
        member this.GetEmission world : Color = this.Get (nameof this.Emission) world
        member this.SetEmission (value : Color) world = this.Set (nameof this.Emission) value world
        member this.Emission = lens (nameof this.Emission) this this.GetEmission this.SetEmission
        member this.GetFlip world : Flip = this.Get (nameof this.Flip) world
        member this.SetFlip (value : Flip) world = this.Set (nameof this.Flip) value world
        member this.Flip = lens (nameof this.Flip) this this.GetFlip this.SetFlip

/// Augments an entity with a static sprite.
type StaticSpriteFacet () =
    inherit Facet (false, false, false)

    static member Properties =
        [define Entity.InsetOpt None
         define Entity.StaticImage Assets.Default.StaticSprite
         define Entity.Color Color.One
         define Entity.Blend Transparent
         define Entity.Emission Color.Zero
         define Entity.Flip FlipNone]

    override this.Render (_, entity, world) =
        let mutable transform = entity.GetTransform world
        let staticImage = entity.GetStaticImage world
        let insetOpt = match entity.GetInsetOpt world with Some inset -> ValueSome inset | None -> ValueNone
        let clipOpt = ValueNone : Box2 voption
        let color = entity.GetColor world
        let blend = entity.GetBlend world
        let emission = entity.GetEmission world
        let flip = entity.GetFlip world
        World.renderLayeredSpriteFast (transform.Elevation, transform.Horizon, staticImage, &transform, &insetOpt, &clipOpt, staticImage, &color, blend, &emission, flip, world)

    override this.GetAttributesInferred (entity, world) =
        match Metadata.tryGetTextureSizeF (entity.GetStaticImage world) with
        | ValueSome size -> AttributesInferred.important size.V3 v3Zero
        | ValueNone -> AttributesInferred.important Constants.Engine.Entity2dSizeDefault v3Zero
```

Here we see that properties are defined in the same way, and even the over-ridden functions have the same signatures as the ones in the Classic `EntityDispatcher`. Here are all of the facet functions available for overriding -

```F#
    /// The presence override, if any.-
    abstract PresenceOverride : Presence voption

    /// Register a facet when adding it to an entity.
    abstract Register : entity : Entity * world : World -> unit

    /// Unregister a facet when removing it from an entity.
    abstract Unregister : entity : Entity * world : World -> unit

    /// Participate in the registration of an entity's physics with the physics subsystem.
    abstract RegisterPhysics : entity : Entity * world : World -> unit

    /// Participate in the unregistration of an entity's physics from the physics subsystem.
    abstract UnregisterPhysics : entity : Entity * world : World -> unit

    /// Update a facet.
    abstract Update : entity : Entity * world : World -> unit

    /// Render a facet.
    abstract Render : renderPass : RenderPass * entity : Entity * world : World -> unit

    /// Participate in attempting to pick an entity with a ray.
    abstract RayCast : ray : Ray3 * entity : Entity * world : World -> Intersection array

    /// Participate in getting the default size of an entity.
    abstract GetAttributesInferred : entity : Entity * world : World -> AttributesInferred

    /// Participate in defining additional editing behavior for an entity via the ImGui API.
    abstract Edit : op : EditOperation * entity : Entity * world : World -> unit
```

As you can see, the `Facet` API is very similar to the Classic `EntityDispatcher` API.

Facets are very convenient in that they allow you to statically compose entities by defining the `Facets` static member in a dispatcher, or programmatically by calling `World.trySetEntityFacetNames`, or dynamically in the editor. If you open up Nu's editor, Gaia, you can create an EntityDispatcher2d and attach a StaticSpriteFacet to it like so -

![image](https://github.com/user-attachments/assets/c188c938-5b2a-4d5b-967d-be2618fd40fe)

Try adding other facets like BasicStaticSpriteEmitterFacet and hitting F5...

Facets are a nice way to statically or dynamically compose entities while minimizing code duplication. You can find many examples of facets in [WorldFacets.fs](https://github.com/bryanedds/Nu/blob/master/Nu/Nu/World/WorldFacets.fs)

***

### Simulant Handles

By now, you've noticed that unlike in imperative game engines, we don't directly access or mutate simulant property values. As a functional engine, this makes intuitive sense, at least, the lack of mutation part. The actual backing store for property value for simulants is in one of two places - either in a (mostly encapsulated) pre-defined F# record (such as `GameState`, `ScreenState`, `GroupState`, or `EntityState`), or in an `Xtension` object contained by one of the aforementioned records. An `Xtension` object is just a property bag with constant-time look-up that allowed dispatchers and facets to dynamically attach properties to a simulant. And it's the above type extensions that defined property getters, setters, and lenses are what expose these user-defined properties via a type-safe interface.

So because the state records and their Xtension objects are what hold the actual property values, they way you as a user identify a particular simulant is via an opaque handle that contains an Address value that the engine uses to look up the underlying state record when it wants to access or update information from it. You're already familiar with Nu's 4 simulant handle types, `Game`, `Screen`, `Group`, and `Entity`, but there's also a parent interface from which they all inherit, `Simulant`.

Using handles to refer to simulants might be a little more indirection than you're used to, but it has massive benefits, such as keeping all values transformations in sync via a single world reference and automatically exposing `ChangeEvent`s for every single simulant property, even the ones you define yourself with the syntax above. In Unity, you can't really even reliably get a property change event, and if you try to get at least a partial one, you have to define it yourself, and the subscription is coupled to the lifetime of the publishing object. Nu gives you a more complete and decoupled property change event model where the event publishing code is all implemented for you.

### Addresses

So we know that simulant handles are constructed from addresses (most conveniently with the overloaded `/` operator), but what is an `Address`?

Simply, it's a series of names that uniquely identify either a simulant or an event in the simulation. Events have their own addresses, and those that involve an event originating from a simulant are appended with the simulant's address. Here are some examples of addresses -

`Game` = The address of the Game simulant, consisting of a single name, "Game". The address of the Game simulant is always the same and can never change. Constructing a Game simulant with any other address will fail.

`Game/MyScreen` = The address of the screen 'MyScreen'

`Game/MyScreen/MyGroup/MyButton` = The address of the entity 'MyButton' inside of a group 'MyGroup' inside of a screen 'MyScreen'

`Mouse/Left/Down/Event` = The address of the left mouse down event.

`Click/Event/Game/MyScreen/MyGroup/MyButton` = The address of the event when MyButton is clicked.

Because simulant events like `Click` use addresses, the subscriber does not need to care about whether the publishing simulant exists in order to subscribe to the event. If the publishing simulant goes away and comes back, the subscription will still be there until the subscriber unsubscribes.

Additionally, you can use wildcards and ellipsis to specify multiple event sources like so -

`Click/Event/Game/MyScreen/MyGroup/*` - specify any click event from any top-level entity in MyGroup.

`Click/Event/Game/MyScreen/...` - specify any click event from any entity in MyScreen.

Note that an address can only contain at most one wildcard or ellipsis since any more would impact performance. Ellipses are also required to be at the end of an address. Additionally, you cannot use wildcard or ellipses in property change events for the same reason.

`^` and `~` enable relative addresses. `^` is the parent symbol and `~` is the current symbol. An address starting with `^` or `~` is a relative address, otherwise it is an absolute address. When `^` is not at the front, it points to the parent of the previous name. When `~` is not at the front, it points to the current name, IE does nothing.

Using relative addresses allows invariance with regards to dragging entity hierarchies around in the Gaia editor, avoiding breakages that would result from absolute addresses.

For `Address.resolve`, when the input relation is absolute, it is returned. When the input relation is relative, it is applied on the input address. For example, applying the relation `^/MyEntity2` on the address `Game/MyScreen/MyGroup/MyEntity1` returns `Game/MyScreen/MyGroup/MyEntity2`.

`Address.relate` can be used to get the relative address between two absolute addresses. For example, relating `Game/MyScreen/MyGroup1/MyEntity1` and `Game/MyScreen/MyGroup2/MyEntity2` gives `^/^/MyGroup2/MyEntity2`.

The empty address is `[]` which is the result of `Game/^`. `[]` cannot be used as a name, so `[]/Name` is invalid. The parent of the empty address is itself, so `Game/^/^` is still `[]`. Note that an empty name is valid, so `‎​` is the absolute address of one empty name, and `/` is the absolute address of two empty names.