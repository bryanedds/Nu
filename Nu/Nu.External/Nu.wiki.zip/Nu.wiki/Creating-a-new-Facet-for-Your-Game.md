Once you have one or more dispatchers that you've created working as intended, you might notice that they share some common behavior you would like to factor out so it can be reused elsewhere. This is what Nu's Facet type is for. Because Facets exist to augment common behavior across entities, they do not use either the ImSim nor MMCC programming model, but rather the Classic Nu programming model. Some example facets that come with the game engine are here -

https://github.com/bryanedds/Nu/blob/master/Nu/Nu/World/WorldFacets.fs

If you would like to create a new Facet type, you can start by copy-pasting the following template.

### Facet Template

1) Replace `Namespace` with your project's name.
2) Replace `Template` with the name of your facet capitalized.
3) Replace `Value` with the name of your facet's property, if any, and `single` with the type of that property, and `1234.5f` with its default value.
4) Create additional facet properties as needed following the example of the previous property.

```F#
namespace Namespace
open System
open Prime
open Nu

[<AutoOpen>]
module TemplateFacet =

    type Entity with
        member this.GetValue world : single = this.Get (nameof this.Value) world
        member this.SetValue (value : single) world = this.Set (nameof this.Value) value world
        member this.Value = lens (nameof this.Value) this this.GetValue this.SetValue
        // TODO: optionally implement more user-defined properties.

    type TemplateFacet () =
        inherit Facet (false, false, false)

        static member Properties =
            [define Entity.Value 1234.5f]

        override this.Register (entity, world) =
            // TODO: optionally implement registration behavior for the faceted entity.
            ()

        override this.Unregister (entity, world) =
            // TODO: optionally implement unregistration behavior for the faceted entity.
            ()

        override this.Update (entity, world) =
            // TODO: optionally implement update code for the faceted entity.
            ()

        override this.Render (entity, world) =
            // TODO: optionally implement rendering code for the faceted entity.
            ()
```