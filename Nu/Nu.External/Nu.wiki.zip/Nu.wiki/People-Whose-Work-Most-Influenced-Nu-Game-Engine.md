* **Casey Muratori** - for ImGui, which partly motivated Nu's ImSim API.
* **Evan Czaplicki** - for MVU and The Elm Architecture, which motivated Nu's MMCC API.
* **Edward Kmett** - for early assistance and for Haskell Lenses, which led to Nu's Property Lens API.
* **Conal Elliott** - for early feedback on Sedela and for FRP, which led to Nu's first experimental form factor, the Chain monad.
* **Brett Victor** - for [Inventing on Principle](https://www.youtube.com/watch?v=PUv66718DII), which led to Nu's human-centeredness and snapshot-based gameplay undo / redo.