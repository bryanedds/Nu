### Follow these steps to create your own Nu project from the Game project template -

1. Install Git - [https://git-scm.com/book/en/v2/Getting-Started-Installing-Git](https://git-scm.com/book/en/v2/Getting-Started-Installing-Git)

2. Install .NET 9.

3. Fork Nu to your github account (sign up if you don't have one) - [https://github.com/bryanedds/Nu/fork](https://github.com/bryanedds/Nu/fork)

4. Clone your fork of Nu via git's `clone` command to your local machine, or if you didn't fork in the previous step, clone Nu via [https://github.com/bryanedds/Nu.git](https://github.com/bryanedds/Nu.git)

5. Create a git branch to work on, either named something general like `dev` or named after the game project you have in mind. This is an important step before getting started with Nu because keeping your master branch free from project-specific changes makes its easy to submit upstream PRs from your master branch directly or from a feature branch off of your master branch.

6. Install an IDE such as Visual Studio 2022, Visual Studio Code, or JetBrains Rider. Make sure to opt-in to installing any components related to developing with F#. If you don't install Visual Studio and are on Windows, you will need to install latest vcredist such as from - https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170

7. If you're on Linux, install the OS-level dependencies by running the `Configure.Linux.Development.sh` shell script found in Nu's root folder.

8. Open up `Nu.sln` from the cloned repo with your chosen editor. In Visual Studio 2022, you'll see a view similar to this -

![image](https://github.com/bryanedds/Nu/assets/1625560/e3e431c7-d64a-4166-9e19-3230cfd3f72a)

9. Expand the Nu folder and, if you're using Visual Studio, right-click the Nu.Gaia project in the Solution Explorer and select, `Set as Startup Project`.

10. Build the solution and Run the Nu.Gaia project, such as by hitting the F5 key in Visual Studio. If it gets stuck on building in Visual Studio, you may have to restart Visual Studio to get it to build the first time due to a bug in its build infrastructure (F# tooling isn't yet completely mature just yet, but otherwise pretty good). You will see a screen like this -

![image](https://github.com/user-attachments/assets/d4bbc202-956f-499c-b77b-902f714fa170)

11. Create a new Nu project that uses the default Nu project template by opening the `Game` dropdown menu, and then clicking New Project. You will see a project creation dialog like so -

![image](https://github.com/user-attachments/assets/6a32548b-9a33-4389-86fe-4b8d172b4f55)

12. Give your Nu game project a valid name. For this example, we'll stick with the default new project name, `My Game` using the ImSim Game project (learn more about new project types [here](https://github.com/bryanedds/Nu/wiki/Choosing-Between-ImSim-and-MMCC-For-Your-Game)). Creating the project will shut down the editor and allow you to run the Nu.Gaia editor with the new project loaded for editing.

13. If using Visual Studio, you will be prompted to reload the solution with the newly-created project. Confirm this request.

14. Expand the Projects folder and you will see your new project in the IDE -

![image](https://github.com/user-attachments/assets/7f1e378f-dfa2-4e08-9229-89c8ec46693a)

15. Build the solution and Run Nu.Gaia again, such as by hitting F5 in Visual Studio. You will see the new game opened for editing in Nu.Gaia -

![image](https://github.com/user-attachments/assets/4ce76859-2843-45d7-80ee-c5ac7e43b695)

16. By clicking the Mode dropdown on the menu, you can select which part of the game to edit -

![image](https://github.com/user-attachments/assets/595db3ee-010f-4857-8565-7e9f1b43a71f)

17. Let's click on Gameplay to edit the demo gameplay level. You will see the following -

![image](https://github.com/user-attachments/assets/7b820b58-f725-4a7e-86a6-4b176b582ac8)

18. On the left side, you will see the editable entity hierarchy. At the top is the Group selection dropdown. In Nu, each game is composed of screens (you've already seen the Title screen and now you're in the Gameplay screen). And each Screen, such as this Gameplay screen, is composed of Groups. In Nu, a Group is just a collection of related Entities, similar to what's known as a 'Scene' in other game engines like Unity. Click the Group selection dropdown like so and you can see the other Group available for editing, `Scene`. Select that group now.

![image](https://github.com/user-attachments/assets/a2540e91-dbc0-4950-bac3-f982b8a9e541)

19. Here you see a mostly empty 3D scene with three entities. You can move the view around as needed with WASD and arrow keys. Click to select objects and drag them to change their position.

20. Now hit F5 in the editor to run the game like so -

![image](https://github.com/user-attachments/assets/bc8e0094-cd68-4bf7-9477-437f0db62f39)

21. The only thing you'll see happening is the StaticModel rotating. Again, this is mostly an empty project.

22. If you edited the Scene in any way, you can save it by hitting Ctrl+S, then navigating to the `Assets` folder, then the `Gameplay` folder, clicking `Scene.nugroup`, then clicking `Save` like so -

![image](https://github.com/user-attachments/assets/06664684-fe0f-4d4f-ad72-85ebf3e8ed09)

When you leave the Gameplay screen (or editor), the entities in that group will be as you left them.

To learn more about building a game in ImSim, check out `Jump Box`, `Breakout ImSim`, `Blaze Vector ImSim`, then `Terra Firma`. Read the ImSim tutorial here - https://github.com/bryanedds/Nu/wiki/Immediate-Mode-for-Games-via-ImSim

To learn more about how to actually start building a game in MMCC, please refer to the existing demo game project available in the solution, going from smallest to biggest, `Nelmish`, `Breakout MMCC`, `Blaze Vector MMCC`, then `Twenty 48`. Be sure to read the MMCC tutorial here first, tho - https://github.com/bryanedds/Nu/wiki/Model-View-Update-for-Games-via-MMCC

# Choosing Between a Game Project and an Empty Project

As you may notice, there's another decision to be made when choosing a new project type in Gaia; that is, whether to use a Game template or an Empty template. The Game templates include all the code and files for a Nu game with a fully articulated, multi-screen life-cycle. If you're ready to make a commercially releasable game title, it's recommended that you use a Game template to get you started quickly and provide good examples of how to make your own additional screens and screen flow.

However, if you just want to play around with and quickly learn either of the APIs with a potential throwaway project, you can choose an Empty template. Alternatively, you can also choose an Empty template if you want complete control of the Nu Game Engine as defined by your exact needs and/or desires.