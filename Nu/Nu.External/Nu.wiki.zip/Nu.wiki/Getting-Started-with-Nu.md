### Follow these steps to create your own Nu project from the default 2D platformer template -

1. Install git - [https://git-scm.com/book/en/v2/Getting-Started-Installing-Git](https://git-scm.com/book/en/v2/Getting-Started-Installing-Git)

2. Fork Nu to your github account (sign up if you don't have one) - [https://github.com/bryanedds/Nu/fork](https://github.com/bryanedds/Nu/fork)

3. Clone your fork of Nu via git's `clone` command to your local machine, or if you didn't fork in the previous step, clone Nu via [https://github.com/bryanedds/Nu.git](https://github.com/bryanedds/Nu.git)

4. Install an IDE such as Visual Studio 2022, Visual Studio Code, or JetBrains Rider. Make sure to opt-in to installing any components related to developing with F#.

5. If you're on Linux, install the OS-level dependencies by running the `Configure.Linux.Development.sh` shell script found in Nu's root folder.

6. Open up `Nu.sln` from the cloned repo with your chosen editor. In Visual Studio 2022, you'll see a view similar to this -

![image](https://github.com/bryanedds/Nu/assets/1625560/e3e431c7-d64a-4166-9e19-3230cfd3f72a)

7. Expand the Nu folder and, if you're using Visual Studio, right-click the Nu.Gaia project in the Solution Explorer and select, `Set as Startup Project`.

8. Build and Run the Nu.Gaia project, such as by hitting the F5 key in Visual Studio. You will see a screen like this -

![image](https://github.com/bryanedds/Nu/assets/1625560/ac470594-0417-4851-96bc-072ce050d4d2)

9. Create a new Nu project that uses the default Nu project template by opening the Project dropdown menu then clicking New Project. You will see a project creation dialog like so -

![image](https://github.com/bryanedds/Nu/assets/1625560/965c0437-fd35-4c98-abf2-87dad2d0495d)

10. Give your Nu game project a valid name. For this example, we'll stick with the default new project name, `MyGame`. Creating the project will shut down the editor and allow you to run the Nu.Gaia editor with the new project loaded for editing.

11. If using Visual Studio, you will be prompted to reload the solution with the newly-created project. Confirm this request to Reload.

12. Expand the projects folder and you will see your new project in the IDE -

![image](https://github.com/bryanedds/Nu/assets/1625560/e2e3b905-b19c-4718-bef1-b18dafb75144)

13. Build and Run again, such as by hitting F5 in Visual Studio. You will see the new game opened for editing in Nu.Gaia -

![image](https://github.com/bryanedds/Nu/assets/1625560/0129e74f-5e07-465b-a04a-69191cdeb63e)

14. By clicking the Mode dropdown on the menu, you can select which part of the game to edit -

![image](https://github.com/bryanedds/Nu/assets/1625560/879bd0e3-6642-40dc-8f88-4ca4947bee65)

15. Let's click on Gameplay to edit the demo gameplay level. You will see the following -

![image](https://github.com/bryanedds/Nu/assets/1625560/5430145d-6d79-4d8b-9de3-3bf7e6d257f2)

16. On the left side, you will see the editable entity hierarchy. At the top, is the Group selection dropdown. In Nu, each game is composed of screens (you've already seen the Title screen and now you're in the Gameplay screen). And each Screen is composed of Groups. In Nu, a group is just a collection of related Entities, similar to what's known as a 'Scene' in other game engines like Unity. Click the Group selection dropdown like so and select the Scene group so we can edit its entities -

![image](https://github.com/bryanedds/Nu/assets/1625560/0440ca12-f9e8-4408-9909-8d7f63c0303c)

17. Move around the blocks to make a flat surface in the game by clicking and dragging them. You can move the view around as needed by clicking and dragging the middle mouse button.

18. Now hit F5 in the editor to run the game like so -

![image](https://github.com/bryanedds/Nu/assets/1625560/8d19f25d-f976-41bf-a503-cdf36530cbfa)

19. Use the arrow keys to navigate Elmario, then hit Ctrl+Z to undo the gameplay.

20. Save your newly edited group by hitting Ctrl+S, then navigating to the `Assets` folder, then the `Gameplay` folder, clicking `Scene.nugroup`, then clicking `Save` like so -

![image](https://github.com/bryanedds/Nu/assets/1625560/8c896015-78a3-4941-b3a2-4db0c6191284)

When you leave the Gameplay screen (or editor), the Entities in the Group will be as you left them.