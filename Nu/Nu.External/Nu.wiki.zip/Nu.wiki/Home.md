# Introductory Material

The following material will help you get started making games with Nu -

[What is Nu and What it Can Do](https://github.com/bryanedds/Nu/wiki/What-is-Nu-and-What-it-Can-Do)

[Getting Started with Nu](https://github.com/bryanedds/Nu/wiki/Getting-Started-with-Nu)

[Model View Update for Games via MMCC](https://github.com/bryanedds/Nu/wiki/Model-View-Update-for-Games-via-MMCC)

[Simplest MMCC Example (Nelmish)](https://github.com/bryanedds/Nu/wiki/Simplest-MMCC-Example-(Nelmish))

[Minimal MMCC Platformer (Elmario)](https://github.com/bryanedds/Nu/wiki/Minimal-MMCC-Platformer-(Elmario))

[Operator Reference](https://github.com/bryanedds/Nu/wiki/Operator-Reference)

[The Game Engine](https://github.com/bryanedds/Nu/wiki/The-Game-Engine)

[Assets and the Asset Graph](https://github.com/bryanedds/Nu/wiki/Assets-and-the-Asset-Graph)

[Accessing Asset Metadata](https://github.com/bryanedds/Nu/wiki/Accessing-Asset-Metadata)

[Skinning Entities with Overlays](https://github.com/bryanedds/Nu/wiki/Skinning-Entities-with-Overlays)

[Playing Music and Sound](https://github.com/bryanedds/Nu/wiki/Playing-Music-and-Sound)