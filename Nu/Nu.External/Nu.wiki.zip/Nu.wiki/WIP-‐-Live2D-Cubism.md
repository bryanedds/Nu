Current algebra for design -

```F#
type CubismModel =
    private { __ : unit }

type CubismParameterInfo =
    { ValueMin : single
      ValueMax : single
      ValueDefault : single
      FriendlyName : string }

type CubismModelPose =
    Map<string, single>

type CubismModelMetadata =
    { ModelParameterInfos : Map<string, CubismParameterInfo>
      ModelPoseDefault : CubismModelPose
      ModelPoses : Map<string, CubismModelPose> }

type CubismModelContext =
    { ModelContainerMemoryPtr : voidptr
      ModelMemoryPtr : voidptr
      ModelContainerPtr : nativeint
      ModelPtr : nativeint }

type CubismContext =
    { CubismModelContexts : Map<CubismModel AssetTag, CubismModelContext>
      CubismModelMetadata : Map<CubismModel AssetTag, CubismModelMetadata> }

type CubismModelDescriptor =
    { ModelParameters : Map<string, single> (* low-level user-facing algebra *)
      ModelPoseOpt : Choice<unit, string, single * string * string> (* high-level user-facing algebra *) }

type RenderOperation2d =
    | ExistingCases
    | RenderCubismModel of CubismModelDescriptor

module Metadata =
    let tryGetCubismModelMetadata (_ : CubismModel AssetTag) : CubismModelMetadata option = Unchecked.defaultof<_>
```